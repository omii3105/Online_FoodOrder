# ExtraAaz Restaurant Website

A modern, responsive, and feature-rich restaurant website built with HTML5, CSS3, Bootstrap 5, and JavaScript.

**Developed by:** Onkar Sonawane  
**Position:** Computer Engineering Intern (3rd Year)  
**Company:** ExtraAaz, Pune

## 🚀 Project Overview

This is a professional restaurant/café/cloud kitchen website featuring:
- Modern glassmorphism design
- Smooth animations and transitions
- Interactive menu filtering
- Customer reviews section
- Online ordering integration
- Fully responsive design

## 📁 Folder Structure

```
restaurant-project/
│
├── index.html                 # Main HTML file
│
├── css/
│   ├── style.css             # Main stylesheet with all custom styles
│   └── animations.css        # Advanced CSS animations and keyframes
│
├── js/
│   ├── main.js              # Main JavaScript functionality
│   └── menu.js              # Menu specific JavaScript (optional)
│
├── images/                   # Image assets folder
│   ├── logo.png             # Restaurant logo
│   ├── hero-bg.jpg          # Hero section background
│   ├── menu/                # Menu item images
│   ├── testimonials/        # Customer photos
│   └── gallery/             # Restaurant gallery images
│
├── assets/                   # Additional assets
│   ├── icons/               # Custom icons
│   └── fonts/               # Custom fonts (if any)
│
└── README.md                # Project documentation
```

## ✨ Features

### 1. **Hero Section**
- Eye-catching gradient background
- Animated statistics counter
- Floating cards with animation
- Call-to-action buttons
- Scroll indicator

### 2. **About Section**
- Image with decorative patterns
- Feature cards with icons
- Smooth animations on scroll
- Premium quality badge

### 3. **Services Section**
- Dine-in seating information
- Fast delivery details
- Online ordering options
- Featured service highlight
- Service features tags

### 4. **Menu Section**
- Interactive filter system (All, Breakfast, Lunch, Dinner, Veg, Non-Veg)
- Beautiful menu cards with hover effects
- Quick view modal
- Rating display
- Add to cart functionality
- Price display with special tags

### 5. **Daily Offers Section**
- Combo meal deals
- Discount badges
- Attractive offer cards
- Call-to-action buttons

### 6. **Reviews Section**
- Customer testimonials
- Star ratings
- Profile images
- Statistics summary
- Animated counters

### 7. **Contact Section**
- Interactive Google Maps
- Contact information cards
- Working hours
- Order platform buttons (WhatsApp, Swiggy, Zomato)

### 8. **Additional Features**
- Fixed navigation with scroll effect
- Floating WhatsApp button
- Scroll to top button
- Toast notifications
- Smooth scroll navigation
- Responsive mobile menu

## 🎨 Design Elements

### Color Scheme
- Primary: #ff6b35 (Orange)
- Secondary: #f7931e (Golden Orange)
- Accent: #c1121f (Red)
- Dark: #1a1a1a (Black)
- Light: #ffffff (White)

### Typography
- Display Font: Playfair Display (serif)
- Body Font: Nunito (sans-serif)
- Handwriting Font: Caveat (cursive)

### Animations
- Fade in/out effects
- Slide animations
- Zoom effects
- Bounce animations
- Gradient shifts
- Hover effects
- Card flips
- Counter animations

## 🛠️ Technologies Used

- **HTML5** - Semantic markup
- **CSS3** - Modern styling with CSS Grid and Flexbox
- **Bootstrap 5** - Responsive framework
- **JavaScript** (ES6+) - Interactive functionality
- **AOS** - Animate On Scroll library
- **Font Awesome** - Icon library
- **Google Fonts** - Custom typography

## 📱 Responsive Design

The website is fully responsive and optimized for:
- Desktop (1920px and above)
- Laptop (1024px - 1919px)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🔧 Installation & Setup

1. **Clone or Download the Project**
   ```bash
   git clone [repository-url]
   ```

2. **Open in Browser**
   - Simply open `index.html` in your browser
   - No build process required

3. **For Development**
   - Use Live Server extension in VS Code
   - Or any local web server

## 📝 Customization Guide

### Changing Colors
Edit CSS variables in `css/style.css`:
```css
:root {
    --primary-color: #ff6b35;
    --secondary-color: #f7931e;
    /* ... more variables */
}
```

### Adding Menu Items
Add new menu cards in the `index.html` menu section:
```html
<div class="col-md-6 col-lg-4 menu-item [category] [veg/nonveg]">
    <!-- Menu card structure -->
</div>
```

### Modifying Animations
Edit animation keyframes in `css/animations.css`

### Updating Contact Information
- Phone numbers in navigation and contact section
- WhatsApp link in floating button
- Google Maps embed in contact section
- Social media links in footer

## 🚀 Deployment

### GitHub Pages
1. Push code to GitHub repository
2. Go to Settings > Pages
3. Select main branch
4. Save and get your URL

### Netlify
1. Connect GitHub repository
2. Deploy with default settings
3. Get your custom domain

### Traditional Hosting
1. Upload all files via FTP
2. Ensure proper file permissions
3. Point domain to hosting

## 📊 Performance Optimization

- Optimized images (WebP format recommended)
- Minified CSS and JavaScript
- Lazy loading for images
- CDN for external libraries
- Efficient animations
- Minimal HTTP requests

## 🔐 Security Considerations

- No sensitive data in frontend
- Form validation
- Sanitized user inputs
- HTTPS recommended for production

## 📄 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## 🐛 Known Issues

None at the moment. Report issues if found.

## 📈 Future Enhancements

- [ ] Online ordering system integration
- [ ] User authentication
- [ ] Admin panel for menu management
- [ ] Payment gateway integration
- [ ] Order tracking system
- [ ] Customer loyalty program
- [ ] Multi-language support
- [ ] Dark mode toggle

## 👨‍💻 Developer Information

**Name:** Onkar Sonawane  
**Course:** Computer Engineering (3rd Year)  
**Company:** ExtraAaz  
**Location:** Pune, Maharashtra  
**Role:** Intern - Web Development

## 📞 Support

For any queries or support:
- Email: [your-email]
- Phone: [your-phone]
- LinkedIn: [your-linkedin]

## 📜 License

This project is proprietary and confidential. All rights reserved by ExtraAaz.

## 🙏 Acknowledgments

- Bootstrap Team for the amazing framework
- Font Awesome for icons
- Google Fonts for typography
- Unsplash for placeholder images
- AOS library for scroll animations

---

**Last Updated:** January 2026  
**Version:** 1.0.0

---

Made with ❤️ by Onkar Sonawane
